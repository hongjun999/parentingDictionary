import React from 'react';
import { Carousel } from 'antd';
import ad3 from '../../img/ad_bar.png';
import AdLeft from './AdLeft';
import Weather from '../Weather/Weather';
import LogInBox from './LogInBox';

const contentStyle = {
  margin: '30px auto 8px auto',
  width: '724px',
  height: '110px',
  backgroundColor: 'RGBA(103,205,238,0.5)',

};
const MiddleLine = () => {
  return (
    <div style={{ position: 'relative', height: '200px' }}>
      <div style={{ margin: '0 auto', width: '725px' }}>
        <a href='/'>
          <Carousel
            pauseOnHover={true}
            autoplay
            autoplaySpeed={5000}
          >
            <div>
              <div style={contentStyle}><img src={ad3} href='/' alt='광고 이미지' /></div>
            </div>
            <div>
              <div style={contentStyle}><img src={ad3} href='/' alt='광고 이미지' /></div>
            </div>
            <div>
              <div style={contentStyle}><img src={ad3} href='/' alt='광고 이미지' /></div>
            </div>
            <div>
              <div style={contentStyle}><img src={ad3} href='/' alt='광고 이미지' /></div>
            </div>
          </Carousel>
        </a>
      </div>
      <div>
        <AdLeft />
        <LogInBox />
      </div>
      <div style={{position: 'relative'}}>
        <Weather />
      </div>
    </div>
  )
}

export default MiddleLine;