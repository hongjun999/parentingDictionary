import React from 'react';
import MiddleLine from './MiddleLine';
import PreViewLine from './PreViewLine/PreViewLine';

const Main = () => {
  return (
    <div>
      <MiddleLine />
      <PreViewLine />
    </div>
  )
}

export default Main