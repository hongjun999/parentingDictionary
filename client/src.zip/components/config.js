export const API_URL = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst'
export const API_KEY = 'SC2a%2BqrUHa%2Fj5owJrOcSg1n98fPBTS73WeIAiXOlWnKYU2bw%2BSQGr2oFmtt39DB79bzKk521LUJmhz%2BoXM8XIw%3D%3D'
