import Main from "./MainPage/Main";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./Navbar/Navbar";


function App() {
  return (
    <div className="App">
      <Navbar />

      <div style={{ minHeight: '130vh' }}>
        <Router basename={process.env.PUBLIC_URL}>
          <Routes>
            <Route path="/" element={<Main />} />
          </Routes>
        </Router>
      </div>


      {/* Footer */}

    </div>
  );
}
export default App;
