import { Flex } from 'antd'
import React from 'react'

const PreViewLine = () => {
  return (
    <div style={{textAlign: 'center', margin: '0 auto'}}>
      <div style={{width: '1200px'}}>
        <Flex><div style={{display: 'inline-block', width:'240px', height: '230px'}}>프리뷰라인</div></Flex>
        <Flex vertical>
          <div style={{ width: '480px', height: '120px'}}>프리뷰라인</div>
          <div style={{}}>프리뷰라인</div>
        </Flex>
      </div>
    </div>
  )
}

export default PreViewLine