import React, { useEffect } from 'react'
import { API_KEY, API_URL } from '../config'

const Weather = () => {

  useEffect(() => {
    let endpointInfo = `${API_URL}?serviceKey=${API_KEY}&numOfRows=10&pageNo=1&base_date=20210628&base_time=0600&nx=55&ny=127`
    fetch(endpointInfo)
      .then(res => {
        console.log(res)
      })


  }, [])
  return(
    <div style={{ position: 'absolute', top: '180px', right: '0'}}>
      날씨 박스
    </div>
  )
}

export default Weather